(function($) {
	 $('.slider').bxSlider({
	 	auto: true,
	 	mode: 'fade',
	 	speed: 500,
	 });
})(jQuery);