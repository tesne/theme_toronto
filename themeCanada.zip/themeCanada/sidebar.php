<div id="secondary" class="secondary">
	<div id="testimoniales">
		<?php dynamic_sidebar('sidebar_2');?>
	</div>	
</div>
<div class="clear"></div>